<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="style-shop.css">
</head>
<body>
    <?php
        // Подключение к базе данных MySQL
    require_once "db.php";

    $conn = db();

        // Проверка соединения
        if ($conn->connect_error) {
            die("Ошибка подключения: " . $conn->connect_error);
        }

        // Запрос данных о товаре
        $sql = "SELECT * FROM product order by id_pictures";
        $result = $conn->query($sql);

        // Запрос изображений товара
        $sql_img = "SELECT id_product, picture, pic_products.id_pictures FROM pic_products, product WHERE product.id_pictures = pic_products.id_pictures order by pic_products.id_pictures";
        $result_img = $conn->query($sql_img);

        echo '<div class="mini-shop">';
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<div class="tovar-2">';

                // Загружаем все изображения для текущего товара
                $images = [];
                $result_img->data_seek(0); // Перемещаем указатель в начало результата запроса
                while ($row_img = $result_img->fetch_assoc()) {
                    if ($row_img['id_pictures'] == $row['id_pictures']) {
                        $images[] = $row_img['picture'];
                    } 
                }

                if (count($images) > 1) {
                      echo '<div class="tovar-img">';

                    // Добавление кнопок переключения слайдов
                        echo '<button class="prev-slide">&#8249;</button>';
                            foreach ($images as $image) {
                                echo '<img src="' . $image . '" class="pic-tovar2" alt="' . $row["name"] . '">';
                            }
                        echo'<button class="next-slide">›</button>';

                            echo '</div>'; // tovar-img
                    } else {
                            echo '<img src="' . $images[0] . '" class="pic-tovarone" alt="' . $row["name"] . '">';
                        }

                        echo '<span class="novice-set">' . $row["name"] .  '</span>';
                        echo '<span class="convenient-first-steps">' . $row["description"] . '</span>';
                        echo '<span class="ruble">' . $row["price"] . ' Р.</span>';
                        
                        echo '<button class="button">
                            <span>Добавить</span>
                            <div class="cart">
                            <svg viewBox="0 0 36 26">
                        <polyline points="1 2.5 6 2.5 10 18.5 25.5 18.5 28.5 7.5 7.5 7.5"></polyline>
                        <polyline points="15 13.5 17 15.5 22 10.5"></polyline></svg>
                            </div>
                            </button>';
                        echo '</div>'; // tovar-2
            }
        } else {
            echo "Товар не найден.";
        }
        
        $conn->close();
    ?>
  <script>
  const sliders = document.querySelectorAll('.tovar-img');
  console.log("JS подключен");

  sliders.forEach(slider => {
    const slides = slider.querySelectorAll('.pic-tovar2');
    let currentSlide = 0;
    slides[currentSlide].classList.add('active');
    function showSlide(n) {
      slides[currentSlide].classList.remove('active');
      currentSlide = n;

      if (currentSlide < 0) {
        currentSlide = slides.length - 1;
      } else if (currentSlide >= slides.length) {
        currentSlide = 0;
      }

      slides[currentSlide].classList.add('active');
    }

    slider.querySelector('.prev-slide').addEventListener('click', () => showSlide(currentSlide - 1));
    slider.querySelector('.next-slide').addEventListener('click', () => {
    console.log(currentSlide+1);   showSlide(currentSlide + 1);});
  });
  </script>
</body>
</html>