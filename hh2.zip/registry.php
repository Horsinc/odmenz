<?php
    require_once "db.php";

    $conn = db();

  // Проверка соединения
  if (!$conn) {
    die('Ошибка подключения: ' . mysqli_connect_error());
  }

  // Получение данных из формы
  $fio = $_POST['fio'];
  $email = $_POST['email'];
  $password = $_POST['password'];
  $password=password_hash($password, PASSWORD_DEFAULT);

  // Подготовка SQL-запроса для добавления данных в таблицу
  $sql = "INSERT INTO clients (fio, email, password, discount) VALUES ('$fio', '$email', '$password', 0)";


  // Проверка успешного выполнения запроса
  if (mysqli_query($conn, $sql)) {
    $result="SELECT * FROM clients WHERE email='$email'";
    $result=mysqli_query($conn,$result);
    $numRows = mysqli_num_rows($result);
    // Проверка успешного выполнения запроса

    if($numRows==1){
      $row=mysqli_fetch_assoc($result);
        if(password_verify($password,$row["password"])){
          setcookie('user', $row['email'], time()+3600,"/");
            // Закрытие соединения
          mysqli_close($conn);
          header('Location: /');}
        }
    
  
  // Закрытие соединения
  mysqli_close($conn);
    echo 'Данные успешно добавлены.';
  } else {
    echo 'Ошибка: ' . mysqli_error($conn);
  }


  header('Location: /')
?>